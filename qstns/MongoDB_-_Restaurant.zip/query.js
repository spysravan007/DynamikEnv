//write your mongo query here
//click on Run > Test/Run from the IDE menu to Test/Run your query
