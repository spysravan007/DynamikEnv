<template>
  <div id="app">
    <h1>
      {{ title }}
    </h1>
    <ul>
      <li >
        <Team />
      </li>
   </ul>
   <div class="add-team">
    <b>Add Team</b>
    <input placeholder="Team name" />
   <button ref="addTeamBtn" >&#8853;</button>
   </div>
  </div>
</template>

<script>
import Team from './components/Team.vue';

export default {
  name: 'app',
  components: {
    Team
  },
  data: () =>({
    title : 'Teams and Channels List',
    teams : [
                   {
                     name: 'Team1',
                     channels: [{
                       name: 'Channel1',
                       index: 1
                     },
                     {
                       name: 'Channel2',
                       index: 2
                     }]
                   },
                   {
                     name: 'Team2',
                     channels: [{
                       name: 'Channel1',
                       index: 1
                     },
                     {
                       name: 'Channel2',
                       index: 2
                     }]
                   }],
    newTeam : ''
  }),
  methods:{
    formValidation: function(value) {
    },
    addTeam: function() {
    }
  }
}
</script>
<style>
* {
  box-sizing: border-box;
  font-size: 15px;
}

body {
  background: #d3f5f2;
  margin-left: 20px;
}
input {
    margin: 0 0.5% 0 4%;
}
</style>
