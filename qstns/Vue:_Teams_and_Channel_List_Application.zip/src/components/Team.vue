<template>
  <div class="team">
    <div>
      <span class="team-name">{{team.name}}</span>
      <button class="sort" >&#8597;</button>
      <span class="add-channel">
        <input placeholder="Channel name" />
        <button ref="addChannelBtn" >&#8853;</button>
      </span>
    </div>
    <div>
      <ul>
        <li >
          <Channel />
        </li>
      </ul>
    </div>
  </div>
</template>

<script scoped>

import Channel from './Channel.vue';
export default {
  name: 'team',
  components: {
    Channel
  },
  data: () => ({
    newChannel : '',
    sortedOrder : 0
  }),
  props: {
    team : {} 
  },
  methods: {
    formValidation: function(value) {
    },
    removeChannel: function(index) {
    },
    addChannel() {
    },
    sort() {
    } 
  }
}
</script>
<style>
.team input {
    margin: 0 0.5% 0 4%;
}
.team{
    padding-bottom:2%;
}
* {
  box-sizing: border-box;
  font-size: 15px;
}

body {
  background: #d3f5f2;
  margin-left: 20px;
}
.sort {
    margin: 0 2% 0 0.5%;
}
.add-channel {
    margin: 4%;
}
</style>
