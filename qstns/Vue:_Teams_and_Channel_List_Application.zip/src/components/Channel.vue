<template>
  <div class="channel-name">
    <span>{{channel.name}}</span>
    <button >&#8854;</button>
  </div>
</template>

<script>

export default {
  name: 'channel',
  props: {
    channel : {}
  }
}
</script>

<style>
.channel-name, span{
    padding: 0 0.4% 0 0;
}
</style>
