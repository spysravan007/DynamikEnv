import { mount } from '@vue/test-utils'
import App from '@/App.vue'
import Team from '@/components/Team.vue'

describe("Tests", () => {
  let wrapper;

  beforeEach(() => {
    wrapper = mount(App);
  });

test('should create the Teams and Channels listing app which contains the teams', () => {
  expect(wrapper.find('.team-name').text()).toBe("Team1");
});

test('teams and channel list should display first team by default along with required inputs and button', () => {
  const teamName = wrapper.find('.team-name');
  const channelSortButton = wrapper.find('.sort');
  const addChannelInput = wrapper.find('.add-channel input');
  const addChannelButton = wrapper.find('.add-channel button');
  expect(teamName).toBeTruthy();
  expect(teamName.text()).toBe("Team1");
  expect(channelSortButton).toBeTruthy();
  expect(channelSortButton.attributes().disabled).toBeFalsy();
  expect(addChannelInput).toBeTruthy();
  expect(addChannelButton).toBeTruthy();
  expect(addChannelButton.attributes().disabled).toBeTruthy();
});

test('teams and channel list should display first channel in team by default along with required buttons', () => {
  const channelName = wrapper.find('.channel-name span');
  const channelRemoveButton = wrapper.find('.channel-name button');
  expect(channelName).toBeTruthy();
  expect(channelName.text()).toBe('Channel1');
  expect(channelRemoveButton).toBeTruthy();
  expect(channelRemoveButton.attributes().disabled).toBeFalsy();
});

test('Add Team section should exist and add button should be disabled initially', () => {
  const addTeam = wrapper.find('.add-team b');
  const addTeamButton = wrapper.find('.add-team button');
  expect(addTeam).toBeTruthy();
  expect(addTeam.text()).toBe("Add Team");
  expect(addTeamButton.attributes().disabled).toBeTruthy();
});

test('Add Team button should not be enabled if data entered in input is empty or numeric', () => {
  const addTeamInput = wrapper.find('.add-team input');
  const addTeamButton = wrapper.find('.add-team button');
  addTeamInput.setValue('');
  expect(addTeamButton.attributes().disabled).toBeTruthy();
  addTeamInput.setValue('1234');
  expect(['true','']).toContain(addTeamButton.attributes().disabled);
});

test('Add Team button should be enabled if data entered in input is correct and clicking on button should add it to the list of teams', () => {
  const addTeamInput = wrapper.find('.add-team input');
  const addTeamButton = wrapper.find('.add-team button');
  addTeamInput.setValue("Team3");
  expect(addTeamButton.attributes().disabled).toBeFalsy();
  addTeamButton.trigger('click');
  const teamNames = wrapper.findAll('.team-name');
  expect(teamNames.at(2).text()).toBe("Team3");
});

test('it should display correct channels name along with remove button', () => {
  const channelName = wrapper.findAll('.channel-name span');
  const channelRemoveButton = wrapper.findAll('.channel-name button');
  expect(channelName).toBeTruthy();
  expect(channelName.at(0).text()).toBe('Channel1');
  expect(channelName.at(1).text()).toBe('Channel2');
  expect(channelRemoveButton).toBeTruthy();
  expect(channelRemoveButton.at(0).disabled).toBeFalsy();
  expect(channelRemoveButton.at(1).disabled).toBeFalsy();
});

test('Add Channel button should exist and should be disabled initially', () => {
  const addChannelButton = wrapper.find('.add-channel button');
  expect(addChannelButton.attributes().disabled).toBeTruthy();
});

test('Add Channel button should not be enabled if data entered in input is empty or numeric', () => {
  const addChannelInput = wrapper.find('.add-channel input');
  const addChannelButton = wrapper.find('.add-channel button');
  addChannelInput.setValue('');
  expect(addChannelButton.attributes().disabled).toBeTruthy();
  addChannelInput.setValue('1234');
  expect(['true','']).toContain(addChannelButton.attributes().disabled);
});

test('Add Channel button should be enabled if data entered in input is correct and clicking on button should add the channel to the existing list', () => {
  const addChannelInput = wrapper.find(Team).find('.add-channel input');
  const addChannelButton = wrapper.find(Team).find('.add-channel button');
  addChannelInput.setValue('Channel3');
  expect(addChannelButton.attributes().disabled).toBeFalsy();
  addChannelButton.trigger('click');
  const channelNames = wrapper.findAll('.channel-name span');
  expect(channelNames.at(0).text()).toBe("Channel1");
  expect(channelNames.at(1).text()).toBe("Channel2");
  expect(channelNames.at(2).text()).toBe("Channel3");
});

test('Clicking on remove button should remove the channel from the list', () => {
  const channelRemoveButton = wrapper.findAll('.channel-name button');
  channelRemoveButton.at(0).trigger('click');
  const channelNames = wrapper.findAll('.channel-name span');
  expect(channelNames.length).toBe(3);
  expect(channelNames.at(0).text()).toBe("Channel2");
  expect(channelNames.at(1).text()).toBe("Channel1");
  expect(channelNames.at(2).text()).toBe("Channel2");
});

test('Clicking on sort button once list the channels in ascending order of names', () => {
  const addChannelInput = wrapper.find('.add-channel input');
  const addChannelButton = wrapper.find('.add-channel button');
  addChannelInput.setValue('Channel0');
  expect(addChannelButton.attributes().disabled).toBeFalsy();
  addChannelButton.trigger('click');
  const channelSortButton = wrapper.find('.sort');
  channelSortButton.trigger('click');
  const channelNames = wrapper.findAll('.channel-name span');
  expect(channelNames.at(0).text()).toBe("Channel0");
  expect(channelNames.at(1).text()).toBe("Channel1");
  expect(channelNames.at(2).text()).toBe("Channel2");
});

it('Clicking on sort button twice list the channels in descending order of names', () => {
  const addChannelInput = wrapper.find('.add-channel input');
  const addChannelButton = wrapper.find('.add-channel button');
  addChannelInput.setValue('Channel0');
  expect(addChannelButton.disabled).toBeFalsy();
  addChannelButton.trigger('click');
  const channelSortButton = wrapper.find('.sort');
  channelSortButton.trigger('click');
  channelSortButton.trigger('click');
  const channelNames = wrapper.findAll('.channel-name span');
  expect(channelNames.at(0).text()).toBe("Channel2");
  expect(channelNames.at(1).text()).toBe("Channel1");
  expect(channelNames.at(2).text()).toBe("Channel0");
});

it('Clicking on sort button thrice list the channels according to creation order', () => {
  const addChannelInput = wrapper.find('.add-channel input');
  const addChannelButton = wrapper.find('.add-channel button');
  addChannelInput.setValue('Channel0');
  expect(addChannelButton.disabled).toBeFalsy();
  addChannelButton.trigger('click');
  const channelSortButton = wrapper.find('.sort');
  channelSortButton.trigger('click');
  channelSortButton.trigger('click');
  channelSortButton.trigger('click');
  const channelNames = wrapper.findAll('.channel-name span');
  expect(channelNames.at(0).text()).toBe("Channel1");
  expect(channelNames.at(1).text()).toBe("Channel2");
  expect(channelNames.at(2).text()).toBe("Channel0");
});

});
