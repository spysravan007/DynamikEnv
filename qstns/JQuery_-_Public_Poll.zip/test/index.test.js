module.exports = {
    "public poll create testing": function (browser) {
      browser
        .url(browser.launch_url)
        .waitForElementVisible("body")

        .click(".main > .btn")
        .setValue(".modal > .pop > form > .textarea",
          "blah..blah..blah..blah"
        )
        .setValue(".modal > .pop > form > input:nth-of-type(1)",
          "blah."
        )
        .setValue(".modal > .pop > form > input:nth-of-type(2)",
          "blah..blah."
        )
        .setValue(".modal > .pop > form > input:nth-of-type(3)",
          "blah..blah..blah."
        )
        .waitForElementVisible(".modal > .pop > .save")
        .click(".modal > .pop > .save")
        .assert.containsText(".options > p",
          "blah..blah..blah..blah"
        )
        .assert.containsText(".options > .btn1",
          "blah."
        )
        .assert.containsText(".options > .btn2",
          "blah..blah."
        )
        .assert.containsText(".options > .btn3",
          "blah..blah..blah."
        )
        .end();
  },
  "public poll create empty testing": function (browser) {
    browser
      .url(browser.launch_url)
      .waitForElementVisible("body")

      .click(".main > .btn")
      .click(".modal > .pop > .save")
      .pause(3000)
      .acceptAlert()
      .setValue(".modal > .pop > form > .textarea",
        "blah..blah..blah..blah"
      )
      .click(".modal > .pop > .save")
      .pause(3000)
      .acceptAlert()
      .end();
  },
  "public poll clear testing": function (browser) {
    browser
      .url(browser.launch_url)
      .waitForElementVisible("body")

      .click(".main > .btn")
      .setValue(".modal > .pop > form > .textarea",
        "blah..blah..blah..blah"
      )
      .setValue(".modal > .pop > form > input:nth-of-type(1)",
        "blah."
      )
      .setValue(".modal > .pop > form > input:nth-of-type(2)",
        "blah..blah."
      )
      .setValue(".modal > .pop > form > input:nth-of-type(3)",
        "blah..blah..blah."
      )
      .click(".modal > .pop > .clear")
      .assert.containsText(".modal > .pop > form > .textarea",
        ""
      ).end();
  },
  "public poll progress testing": function (browser) {
    browser
      .url(browser.launch_url)
      .waitForElementVisible("body")

      .click('.options > .btn1')
      .assert.containsText(".btn4",
        "1"
      )
      .click('.options > .btn2')
      .assert.containsText(".btn5",
        "1"
      )
      .click('.options > .btn3')
      .assert.containsText(".btn6",
        "1"
      )
      .click(".btn7")
      .assert.containsText(".modal1 > .pop1 > .form > .box1 > .label1",
        "ReactJS"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box2 > .label2",
        "Angular"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box3 > .label3",
        "VueJS"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box1 > .currentscore1",
        "1"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box2 > .currentscore2",
        "1"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box3 > .currentscore3",
        "1"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box1 > .percentage1",
        "33"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box2 > .percentage2",
        "33"
      )
      .assert.containsText(".modal1 > .pop1 > .form > .box3 > .percentage3",
        "33"
      )
      .end();
  },
};
  